const projects = {
  agrobox: {
    tag: "Agricultura · IoT",
    title: "AgroBox 2.0",
    description:
      "Herramienta orientada al análisis de suelo para apoyar la toma de decisiones en cultivos y mejorar la gestión agrícola.",
    items: [
      ["Problemática", "Necesidad de contar con información sobre las condiciones del suelo para apoyar decisiones agrícolas."],
      ["Investigación", "Se estudia el contexto de aplicación y las variables que pueden aportar información útil."],
      ["Desarrollo", "Se integran sensores, electrónica y herramientas digitales en un prototipo portátil."],
      ["Evaluación", "El desarrollo se prueba, se analizan resultados y se realizan mejoras."],
      ["Propósito", "Generar información que apoye la gestión y toma de decisiones en el ámbito agrícola."]
    ]
  },

  mednigent: {
    tag: "Agua · IoT",
    title: "MedNiGent 2.0",
    description:
      "Sistema orientado al monitoreo del recurso hídrico y de variables relacionadas con el consumo y la calidad del agua.",
    items: [
      ["Problemática", "Surge ante necesidades relacionadas con el monitoreo del consumo y de variables del agua."],
      ["Variables", "Integra medición de flujo, pH, temperatura, sólidos disueltos totales y turbidez."],
      ["Desarrollo", "Combina sensores con un sistema electrónico para adquisición, procesamiento, almacenamiento y visualización."],
      ["Evaluación", "El sistema se prueba y se realizan ajustes para mejorar su funcionamiento."],
      ["Propósito", "Aportar información para observar y gestionar el recurso hídrico."]
    ]
  },

  beelens: {
    tag: "Accesibilidad",
    title: "BeeLens",
    description:
      "Proyecto de desarrollo tecnológico relacionado con accesibilidad y necesidades visuales.",
    items: [
      ["Problemática", "Parte de una necesidad relacionada con accesibilidad identificada en el entorno."],
      ["Investigación", "Se analiza el contexto y las necesidades que debe atender la propuesta."],
      ["Desarrollo", "La idea se convierte en una propuesta tecnológica mediante experimentación y prototipado."],
      ["Evaluación", "Se prueban los resultados y se identifican oportunidades de mejora."],
      ["Propósito", "Explorar cómo la tecnología puede ampliar posibilidades de accesibilidad."]
    ]
  },

  showergent: {
    tag: "Turismo · Agua",
    title: "ShowerGent",
    description:
      "Solución enfocada en el monitoreo de condiciones del agua y la experiencia de uso en espacios como hoteles y departamentos.",
    items: [
      ["Problemática", "Se relaciona con el uso del agua y las condiciones de utilización del recurso."],
      ["Investigación", "Se observa el contexto de aplicación para definir las necesidades tecnológicas."],
      ["Desarrollo", "Se plantea y construye una solución tecnológica orientada al contexto de uso."],
      ["Evaluación", "La propuesta se prueba para detectar ajustes y oportunidades de mejora."],
      ["Propósito", "Promover un uso más consciente y eficiente del recurso hídrico."]
    ]
  },

  agroshield: {
    tag: "Agricultura · Monitoreo",
    title: "AgroShield Istmo",
    description:
      "Nueva línea de desarrollo relacionada con el monitoreo ambiental en árboles de mango y la continuidad del ciclo de innovación.",
    items: [
      ["Nueva problemática", "Representa una nueva línea de desarrollo que surge a partir de otra necesidad del entorno."],
      ["Monitoreo", "El sistema contempla el registro de variables ambientales relacionadas con el cultivo."],
      ["Continuidad", "AgroShield muestra que el Modelo Genterra puede reiniciar el ciclo ante nuevas preguntas."],
      ["Evaluación", "El desarrollo puede evolucionar mediante pruebas, resultados y retroalimentación."],
      ["Propósito", "Apoyar la gestión del cultivo mediante información y monitoreo tecnológico."]
    ]
  }
};

const modal = document.getElementById("projectModal");
const modalTag = document.getElementById("modalTag");
const modalTitle = document.getElementById("modalTitle");
const modalDescription = document.getElementById("modalDescription");
const modalProcess = document.getElementById("modalProcess");

function openProject(key) {
  const project = projects[key];
  if (!project) return;

  modalTag.textContent = project.tag;
  modalTitle.textContent = project.title;
  modalDescription.textContent = project.description;

  modalProcess.innerHTML = project.items.map(([title, text]) => `
    <article class="case-item">
      <h3>${title}</h3>
      <p>${text}</p>
    </article>
  `).join("");

  modal.classList.add("active");
  modal.setAttribute("aria-hidden", "false");
  document.body.classList.add("modal-open");
}

function closeProject() {
  modal.classList.remove("active");
  modal.setAttribute("aria-hidden", "true");
  document.body.classList.remove("modal-open");
}

document.querySelectorAll("[data-project]").forEach(button => {
  button.addEventListener("click", () => openProject(button.dataset.project));
});

document.querySelectorAll("[data-close-modal]").forEach(element => {
  element.addEventListener("click", closeProject);
});

document.addEventListener("keydown", event => {
  if (event.key === "Escape" && modal.classList.contains("active")) {
    closeProject();
  }
});

document.querySelectorAll('a[href^="#"]').forEach(link => {
  link.addEventListener("click", event => {
    const target = document.querySelector(link.getAttribute("href"));
    if (target) {
      event.preventDefault();
      target.scrollIntoView({ behavior: "smooth" });
    }
  });
});
