GENTERRA — WEB ACTUALIZADA

Estructura:
Genterra_Web_Actualizada/
├── index.html
├── css/style.css
├── js/script.js
└── img/logo.png

Cómo ejecutar:
1. Abre la carpeta.
2. Abre index.html con Chrome/Edge.
3. Para editar estilos, usa css/style.css.
4. Para editar las fichas de proyectos, usa js/script.js.

Imágenes de proyectos:
Las tarjetas tienen actualmente composiciones visuales en CSS para que el sitio funcione inmediatamente.
Puedes sustituirlas después por fotografías reales de AgroBox, MedNiGent, BeeLens, ShowerGent y AgroShield sin cambiar la estructura de las tarjetas.

La navegación, el modal de proyectos, el diseño responsive y el desplazamiento suave ya están incluidos.
